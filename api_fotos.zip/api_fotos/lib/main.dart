import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'API de Fotos',
      theme: ThemeData(
        primaryColor: const Color.fromARGB(255, 93, 119, 119),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color.fromARGB(255, 93, 119, 119),
        ),
        scaffoldBackgroundColor: const Color.fromARGB(255, 31, 46, 46),
      ),
      home: const MyHomePage(title: ''),
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildUnderlineText('GERADOR'),
            const Text(
              ' DE ',
              style: TextStyle(
                color: Colors.black,
                fontSize: 34,
                fontWeight: FontWeight.bold,
              ),
            ),
            _buildUnderlineText('IMAGENS'),
          ],
        ),
        centerTitle: true,
        elevation: 0, // Remove a sombra para um efeito fluido
      ),
      body: Padding(
        padding:
            const EdgeInsets.symmetric(horizontal: 30), // Espaçamento lateral
        child: SingleChildScrollView(
          // Adicionado para permitir o scroll
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Espaço entre o cabeçalho e as faixas
              const SizedBox(height: 50),
              // Primeira faixa: "GERADOR"
              _buildTitleContainer(
                color: Colors.white,
                height: 60,
                child: const Center(
                  child: Text(
                    'GERADOR',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 33,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              // Segunda faixa: Imagem
              _buildColoredSection(
                color: const Color.fromARGB(255, 148, 173, 173),
                height: 450,
                child: _buildPhotoContainer(),
              ),
              const SizedBox(height: 20),
              // Botão Gerar Imagem
              _buildGenerateButton(),
            ],
          ),
        ),
      ),
    );
  }

  // Cabeçalho
  Widget _buildUnderlineText(String text) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Text(
          text,
          style: const TextStyle(
            color: Colors.black,
            fontSize: 34,
            fontWeight: FontWeight.bold,
          ),
        ),
        Positioned(
          bottom: -4,
          child: Container(
            height: 5.5,
            width: text.length * 22,
            color: Colors.black,
          ),
        ),
      ],
    );
  }

  // Primeira faixa (GERADOR)
  Widget _buildTitleContainer({
    required Color color,
    required double height,
    required Widget child,
  }) {
    return Container(
      height: height,
      decoration: BoxDecoration(
        color: color,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(35),
          topRight: Radius.circular(35),
        ),
      ),
      alignment: Alignment.center,
      child: child,
    );
  }

  // Segunda faixa (Imagem)
  Widget _buildColoredSection({
    required Color color,
    required double height,
    Widget? child,
  }) {
    return Container(
      height: height,
      decoration: BoxDecoration(
        color: color,
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(13),
          bottomRight: Radius.circular(13),
        ),
      ),
      child: Center(child: child),
    );
  }

  // Contêiner de borda da foto
  Widget _buildPhotoContainer() {
    return Container(
      margin: const EdgeInsets.all(20), // Margem interna na faixa
      padding: const EdgeInsets.all(10), // Espaçamento interno da borda
      decoration: BoxDecoration(
        color: Colors.white, // Cor do contêiner (div interna)
        borderRadius: BorderRadius.circular(10), // Borda arredondada
      ),
      child: _buildPhotoSection(),
    );
  }

  // Foto única dentro do contêiner
  Widget _buildPhotoSection() {
    const String imageUrl =
        'https://via.placeholder.com/300'; // Substituir pela URL da API
    return ClipRRect(
      borderRadius: BorderRadius.circular(10), // Borda arredondada na foto
      child: Image.network(
        imageUrl,
        fit: BoxFit.cover, // Ajusta a imagem para preencher o espaço
        loadingBuilder: (context, child, loadingProgress) {
          if (loadingProgress == null) {
            return child; // Mostra a imagem quando carregada
          } else {
            return const Center(
              child: CircularProgressIndicator(), // Indicador de carregamento
            );
          }
        },
        errorBuilder: (context, error, stackTrace) {
          return const Center(
            child: Text(
              'Erro ao carregar imagem',
              style: TextStyle(color: Colors.red),
            ),
          );
        },
      ),
    );
  }

  // Botão Gerar Imagem
  Widget _buildGenerateButton() {
    return ElevatedButton(
      onPressed: () {
        // Aqui você pode adicionar a lógica para gerar a imagem, por enquanto apenas um print
        print('Gerar Imagem!');
      },
      style: ElevatedButton.styleFrom(
        primary: Colors.black, // Cor de fundo
        onPrimary: Colors.white, // Cor do texto
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30), // Bordas arredondadas
        ),
        padding: const EdgeInsets.symmetric(vertical: 23), // Tamanho do botão
        textStyle: const TextStyle(
          fontSize: 30, // Tamanho da fonte
        ),
      ),
      child: const Text('Gerar Imagem'),
    );
  }
}
