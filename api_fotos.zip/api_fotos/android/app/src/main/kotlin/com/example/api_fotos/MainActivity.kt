package com.example.api_fotos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
